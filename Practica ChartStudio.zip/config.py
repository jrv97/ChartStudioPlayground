# Dataset path
data_path = "data/student-mat.csv"
# Chart Studio account settings
username = 'PLOTLY_USERNAME'
api_key = 'CHART_STUDIO_API_KEY'
